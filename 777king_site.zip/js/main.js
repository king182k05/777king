
function showGame(game) {
    document.querySelectorAll('.game-section').forEach(section => section.style.display = 'none');
    document.getElementById(game).style.display = 'block';
}

function playRoulette() {
    const result = Math.floor(Math.random() * 37);
    document.getElementById('roulette-result').innerText = `Resultado: ${result}`;
}

function playSlot() {
    const symbols = ['7', 'BAR', '🍒', '💎', '⭐'];
    const result = [0, 0, 0].map(() => symbols[Math.floor(Math.random() * symbols.length)]);
    document.getElementById('slot-result').innerText = `Resultado: ${result.join(' | ')}`;
}

function startBlackjack() {
    const player = drawCard() + drawCard();
    const dealer = drawCard() + drawCard();
    const result = `Jogador: ${player} | Dealer: ${dealer}`;
    document.getElementById('blackjack-game').innerText = result;
}

function drawCard() {
    return Math.floor(Math.random() * 10) + 1;
}
